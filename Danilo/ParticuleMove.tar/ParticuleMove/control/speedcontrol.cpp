#include "speedcontrol.h"

SpeedControl::SpeedControl()
{

}
double SpeedControl::easyIn_easyOut(double t, double k1, double k2){
    return easyIn_easyOut(t);
    double f,s;
    if (t == 0) return 0.0;
    f = k1*2/M_PI + k2 - k1 + (1.0-k2)*2/M_PI;
    if (t < k1) {
        s = k1*(2/M_PI)*(sin((t/k1)*(M_PI_2)-M_PI_2)+1);
    }
    else if (t > k2) {
        s= k1/M_PI_2 + k2-k1 + ((1-k2)*(2/M_PI))*sin(((t-k2)/(1.0-k2))*M_PI_2);
    }
    else {
        s = (k1/M_PI_2 + t-k1);
    }
    return (s/f);
}

double SpeedControl::easyIn_easyOut(double t){
    double t_s = (sin(t*M_PI - M_PI_2)+1)/2.0;
    return t_s;
}
