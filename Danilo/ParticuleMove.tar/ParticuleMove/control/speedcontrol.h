#ifndef SPEEDCONTROL_H
#define SPEEDCONTROL_H
#include <math.h>
class SpeedControl
{
public:
    SpeedControl();
    static double easyIn_easyOut(double t, double k1, double k2);
    static double easyIn_easyOut(double t);
};

#endif // SPEEDCONTROL_H
