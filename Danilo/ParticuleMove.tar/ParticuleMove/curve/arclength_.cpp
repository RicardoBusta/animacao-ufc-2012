#include "arclength_.h"
#include <stdio.h>
#define MODULUS(x) (x<0?-x:x)
/*definições da class Table_Entry*/
Table_Entry::Table_Entry():u(0.0),length(0.0)
{
}
Table_Entry::Table_Entry(double u_,double length_):u(u_),length(length_)
{
}

void Table_Entry::showTableEntry()
{
    printf("\n u: %.4f | length: %.4f",u,length);
}

/*definições da class Interval_Structure*/
Interval_Structure::Interval_Structure(): u1(0.0),u2(0.0),length(0.0)
{

}

Interval_Structure::Interval_Structure(double u1_,double u2_, double length_): u1(u1_),u2(u2_),length(length_)
{

}

void Interval_Structure::showIntervalStructure()
{
    printf("\n[u1: %4f,u2: %4f] | length: %f",u1,u2,length);
}

/*definições da class Polinomial  */
Polynomial::Polynomial()
{
}
Polynomial::~Polynomial()
{

}

double Polynomial::evaluate_polynomial(Polynomial *poly, double u)
{

    double w;
    int    i;
    double value;

    value = 0.0;
    w = 1.0;
    for (i=0; i<=poly->degree; i++)
    {
        value += poly->coeff[i]*w;
        w *= u;
    }
    if (isnan(value)){
        value = 1;
    }
    return value;

}

void Polynomial::show(){

}


/*definições da class ArcLength_*/
ArcLength_::ArcLength_()
{
    is_calculate = false;
    teste = false;
    table.append(Table_Entry());
}



//ADAPTIVE INTEGRATION
//this is the high-level call used whenever a curve's length is to be computed

void ArcLength_::adaptive_integration(Curve *curve, double u1, double u2, double tolerance)
{
    if (is_calculate) return;
    //double subdivide();
    Polynomial func;
    ArcLength_ full_interval;
    double total_length;
    //double integrate_func();
    double temp;

    Vec4 a1 = curve->a();
    Vec4 b1 = curve->b();
    Vec4 c1 = curve->c();



    func.degree = 4;
    func.coeff = (double *)malloc(sizeof(double)*5);
    func.coeff[4] = 9*(a1.x1*a1.x1 + a1.x2*a1.x2 + a1.x3*a1.x3);
    func.coeff[3] = 12*(a1.x1*b1.x1 + a1.x2*b1.x2 + a1.x3*b1.x3);
    func.coeff[2] = (6*(a1.x1*c1.x1 + a1.x2*c1.x2 + a1.x3*c1.x3) + 4*(b1.x1*b1.x1 + b1.x2*b1.x2 + b1.x3*b1.x3));
    func.coeff[1] = 4*(b1.x1*c1.x1 +  b1.x2*c1.x2 + b1.x3*c1.x3);
    func.coeff[0] = (c1.x1*c1.x1 + c1.x2*c1.x2 + c1.x3*c1.x3);

    full_interval.u1 = u1;
    full_interval.u2 = u2;


    temp = integrate_func(&func, &full_interval);

//    printf("\nInitial guess = %lf; %lf:%lf",temp,u1,u2);

    full_interval.length = temp;
    total_length = subdivide(&full_interval, &func, 0.0, tolerance);

//    for(int i=0;i<table.size();i++){
//        printf("\n[%d] U: %.3f | S: %.3f",i,table[i].u,table[i].length);
//    }
//    printf("\n total length = %lf\n",total_length);
    this->length = total_length;
    is_calculate = true;


}
//SUBDIVIDE
/*'total_length' is the length of the curve up to, but not including, the
'full_interval'
if the difference between the interval and the sum of its halves is less
than 'tolerance,'
stop the recursive subdivision
'func' is a polynomial function
*/

double ArcLength_::subdivide(ArcLength_ *full_interval, Polynomial *func, double total_length, double tolerance)
{
    ArcLength_ left_interval;
    ArcLength_ right_interval;
    double left_length;
    double right_length;
    double midu;
    //double subdivide();
    //double integrate_func();
    double temp;
    //void add_table_entry();


    midu = (full_interval->u1+full_interval->u2)/2.0;
    left_interval.u1 = full_interval->u1;
    left_interval.u2 = midu;
    right_interval.u1 = midu;
    right_interval.u2 = full_interval->u2;
    left_length = integrate_func(func, &left_interval);
    right_length = integrate_func(func, &right_interval);
    temp = fabs(full_interval->length - (left_length+right_length));
    if (temp > tolerance)
    {
        left_interval.length = left_length;
        right_interval.length = right_length;
        total_length = subdivide(&left_interval, func, total_length, tolerance);
        total_length = subdivide(&right_interval, func, total_length, tolerance);
        return(total_length);
    }
    else
    {

        total_length = total_length + left_length;
        //add_table_entry(midu,total_length);
        //Table_Entry tab(midu,total_length);
        table.append(Table_Entry(midu,total_length));
        total_length = total_length + right_length;
        //add_table_entry(full_interval->u2,total_length);
        table.append(Table_Entry(full_interval->u2,total_length));
        return(total_length);
    }

 }
//INTEGRATE FUNCTION
/*use Gaussian quadrature to integrate square root of given function in the
given interval
*/

double ArcLength_::integrate_func(Polynomial *func, ArcLength_ *interval)
{
    double x[5]= {.1488743389,.4333953941,.6794095682,.8650633666, .9739065285};
    double w[5]={.2966242247,.2692667193,.2190863625,.1494513491,.0666713443};
    double length, midu, dx, diff;
    int i;
    //double evaluate_polynomial();
    double u1,u2;
    u1 = interval->u1;
    u2 = interval->u2;
    midu = (u1+u2)/2.0;
    diff = (u2-u1)/2.0;
    length = 0.0;
    dx = 0;
    for (i=0; i<5; i++)
    {
        Polynomial p;
        double pol1 = p.evaluate_polynomial(func,midu+dx);
        double pol2 = p.evaluate_polynomial(func,midu-dx);
        dx = diff*x[i];
        length += (sqrt(pol1) + sqrt(pol2))*w[i];
    }
    length *= diff;



    return (length);



}

Vec4 ArcLength_::getVec4S(Curve *curve,double s)
{



    int indice = 0;
    for (int i = 1;i<table.size();i++){
        if(table[i].length >= s && table[i-1].length <= s){
            indice = i-1;
        }
    }
    double u = getU(indice,s);

    return curve->Evaluate(u);

}

double ArcLength_::getU(int indice,double s)
{
    double u1,u2,s1,s2,u;

    u1 = table[indice].u;
    u2 = table[indice+1].u;

    s1 = table[indice].length;
    s2 = table[indice+1].length;
    u = (s*(2*u1*u2-u1*u1-u2*u2)) - ((u1*u2-u2*u2)*s1) - ((u1*u2-u1*u1)*s2);
    u = u/((u2-u1)*s1+(u1-u2)*s2);

    return u;


}

Vec4 ArcLength_::getVec4V(Curve *curve, double s)
{
    int indice = 0;
    for (int i = 1;i<table.size();i++){
        if(table[i].length >= s && table[i-1].length <= s){
            indice = i-1;
        }
    }
    double u = getU(indice,s);

    return curve->Velocity(u);
}

Vec4 ArcLength_::getVec4A(Curve *curve, double s)
{
    int indice = 0;
    for (int i = 1;i<table.size();i++){
        if(table[i].length >= s && table[i-1].length <= s){
            indice = i-1;
        }
    }
    double u = getU(indice,s);

    return curve->Aceleration(u);
}

