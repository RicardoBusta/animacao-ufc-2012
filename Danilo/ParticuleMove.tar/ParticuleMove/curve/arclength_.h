#ifndef ARCLENGTH__H
#define ARCLENGTH__H
#include <QVector>
#include "curve.h"
class Table_Entry {
public:
    double u,length;
    Table_Entry();
    Table_Entry(double,double);
    void showTableEntry();

};

class Interval_Structure {
public:
    double u1,u2;
    double length;

    Interval_Structure();
    Interval_Structure(double u1_,double u2_, double length_);
    void showIntervalStructure();

};

class Polynomial
{
public:
    Polynomial();
    double *coeff;
    int degree;

    double evaluate_polynomial(Polynomial *poly, double );

    ~Polynomial();
    void show();
};

class ArcLength_
{
public:
    ArcLength_();
    //Interval_Structure interval;
    double u1,u2;
    double length;
    QVector<Table_Entry> table;
    bool is_calculate,teste;
    Curve *c;

    void adaptive_integration(Curve *curve, double, double, double);
    double subdivide(ArcLength_ *full_interval, Polynomial *func, double, double);
    double integrate_func(Polynomial *func, ArcLength_ *interval);
    Vec4 getVec4S(Curve *curve,double s); //achar o Vetor Posição dado o espaço
    Vec4 getVec4V(Curve *curve,double s); //achar a Vetor Velocidade dado o espaço
    Vec4 getVec4A(Curve *curve,double s); //achar a Vetor Aceleração dado o espaço
    double getU(int indice,double s);

};

#endif // ARCLENGTH__H

