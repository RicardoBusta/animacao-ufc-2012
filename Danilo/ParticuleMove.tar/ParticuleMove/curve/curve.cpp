#include "curve.h"
#define MAX 100.0


/****************** Bezier Curve  ********************************/
BezierCubic::BezierCubic(): p_size(1.0),l_size(1.0)
{

}
BezierCubic::BezierCubic(Vec4 a,Vec4 b, Vec4 c,Vec4 d): p_a(a),p_b(b),p_c(c),p_d(d)
{

}

Vec4 BezierCubic::Evaluate(double t)
{
    double b0,b1,b2,b3;
    b0 = -t*t*t + 3*t*t -3*t + 1;
    b1 = 3*t*t*t - 6*t*t + 3*t;
    b2 = -3*t*t*t +3*t*t;
    b3 = t*t*t;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;
}

Vec4 BezierCubic::Velocity(double t)
{
    double b0,b1,b2,b3;
    b0 = -3*t*t + 6*t -3;
    b1 = 9*t*t - 12*t + 3;
    b2 = -9*t*t +6*t;
    b3 = 3*t*t;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;
}

Vec4 BezierCubic::Aceleration(double t)
{
    double b0,b1,b2,b3;
    b0 = -6*t + 6;
    b1 = 18*t - 12;
    b2 = -18*t +6;
    b3 = 6*t;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;
}


Vec4 BezierCubic::a(){
    Vec4 a;
    a.x1 = -1*p_a.x1+3*p_b.x1-3*p_c.x1+1*p_d.x1;
    a.x2 = -1*p_a.x2+3*p_b.x2-3*p_c.x2+1*p_d.x2;
    a.x3 = -1*p_a.x3+3*p_b.x3-3*p_c.x3+1*p_d.x3;
    return a;
}

Vec4 BezierCubic::b(){
    Vec4 a;
    a.x1 = 3*p_a.x1-6*p_b.x1+3*p_c.x1+0*p_d.x1;
    a.x2 = 3*p_a.x2-6*p_b.x2+3*p_c.x2+0*p_d.x2;
    a.x3 = 3*p_a.x3-6*p_b.x3+3*p_c.x3+0*p_d.x3;
    return a;
}

Vec4 BezierCubic::c(){
    Vec4 a;
    a.x1 = -3*p_a.x1+3*p_b.x1-0*p_c.x1+0*p_d.x1;
    a.x2 = -3*p_a.x2+3*p_b.x2-0*p_c.x2+0*p_d.x2;
    a.x3 = -3*p_a.x3+3*p_b.x3-0*p_c.x3+0*p_d.x3;
    return a;
}

void BezierCubic::draw(QList<Vec4> )
{
    int j = 0;
    do{
        glColor3f(1.0,0.5,0.0);
        Vec4::drawLineVec4(Evaluate(j/MAX),Evaluate((j+1)/MAX),l_size);
        j++;
    }while(j<=MAX);

}

void BezierCubic::drawPolygon(QList<Vec4> vertexs)
{
    glColor3f(1.0,1.0,1.0);
    glBegin(GL_LINE_STRIP);
    for(int i=0;i<vertexs.size();i++){
        glVertex3f(vertexs[i].x1,vertexs[i].x2,vertexs[i].x3);
    }
    glEnd();
}

void BezierCubic::drawCurve(QList<Vec4> vertexs,bool show_polygon, bool show_curve)
{
    p_a = vertexs[0];
    p_b = vertexs[1];
    p_c = vertexs[2];
    p_d = vertexs[3];
    if (show_curve)   draw(vertexs);
    if (show_polygon) drawPolygon(vertexs);
}

/*********************************** CatmullRom Spline ******************************/

CatmullRomSpline::CatmullRomSpline(): p_size(1.0),l_size(1.0)
{

}

CatmullRomSpline::CatmullRomSpline(Vec4 a,Vec4 b, Vec4 c,Vec4 d): p_a(a),p_b(b),p_c(c),p_d(d)
{

}

Vec4 CatmullRomSpline::Evaluate(double t)
{
    double b0,b1,b2,b3;
    b0 = (-t*t*t + 2*t*t -t)/2;
    b1 = (3*t*t*t - 5*t*t + 2)/2;
    b2 = (-3*t*t*t +4*t*t +t)/2;
    b3 = (t*t*t -t*t)/2;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;
}

void CatmullRomSpline::drawCurve(QList<Vec4> vertexs,bool show_polygon,bool show_curve)
{
    if (show_curve)   draw(vertexs);
    if (show_polygon) drawPolygon(vertexs);
}

void CatmullRomSpline::drawPolygon(QList<Vec4> vertexs)
{
    glColor3f(1.0,1.0,1.0);
    glBegin(GL_LINE_STRIP);
    for(int i=0;i<vertexs.size();i++){
        glVertex3f(vertexs[i].x1,vertexs[i].x2,vertexs[i].x3);
    }
    glEnd();
}

void CatmullRomSpline::draw(QList<Vec4> vertexs)
{
    for (int i=0;i<vertexs.size()-1;i++){
        p_a = vertexs[std::max(0,i-1)];
        p_b = vertexs[i];
        p_c = vertexs[std::min(i+1,vertexs.size()-1)];
        p_d = vertexs[std::min(i+2,vertexs.size()-1)];

        int j = 0;
        do{
            glColor3f(1.0,0.5,0.0);
            Vec4::drawLineVec4(Evaluate(j/MAX),Evaluate((j+1)/MAX),l_size);
            j++;
        }while(j<=MAX);
    }
}

Vec4 CatmullRomSpline::a()
{
    Vec4 a;
    a.x1 = (-1*p_a.x1+3*p_b.x1-3*p_c.x1+1*p_d.x1)/2.0;
    a.x2 = (-1*p_a.x2+3*p_b.x2-3*p_c.x2+1*p_d.x2)/2.0;
    a.x3 = (-1*p_a.x3+3*p_b.x3-3*p_c.x3+1*p_d.x3)/2.0;
    return a;
}

Vec4 CatmullRomSpline::b()
{
    Vec4 a;
    a.x1 = (2*p_a.x1-5*p_b.x1+4*p_c.x1-1*p_d.x1)/2.0;
    a.x2 = (2*p_a.x2-5*p_b.x2+4*p_c.x2-1*p_d.x2)/2.0;
    a.x3 = (2*p_a.x3-5*p_b.x3+4*p_c.x3-1*p_d.x3)/2.0;
    return a;
}

Vec4 CatmullRomSpline::c()
{
    Vec4 a;
    a.x1 = (-1*p_a.x1+0*p_b.x1+1*p_c.x1+0*p_d.x1)/2.0;
    a.x2 = (-1*p_a.x2+0*p_b.x2+1*p_c.x2+0*p_d.x2)/2.0;
    a.x3 = (-1*p_a.x3+0*p_b.x3+1*p_c.x3+0*p_d.x3)/2.0;
    return a;
}

Vec4 CatmullRomSpline::Velocity(double t)
{
    double b0,b1,b2,b3;
    b0 = (-3*t*t + 4*t -1)/2;
    b1 = (9*t*t - 10*t)/2;
    b2 = (-9*t*t +8*t +1)/2;
    b3 = (3*t*t -2*t)/2;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;

}

Vec4 CatmullRomSpline::Aceleration(double t)
{
    double b0,b1,b2,b3;
    b0 = (-6*t + 4)/2;
    b1 = (18*t - 10)/2;
    b2 = (-18*t +8)/2;
    b3 = (6*t -2)/2;
    Vec4 p;
    p.x1 = p_a.x1*b0 + p_b.x1*b1 + p_c.x1*b2 + p_d.x1*b3;
    p.x2 = p_a.x2*b0 + p_b.x2*b1 + p_c.x2*b2 + p_d.x2*b3;
    p.x3 = p_a.x3*b0 + p_b.x3*b1 + p_c.x3*b2 + p_d.x3*b3;
    return p;

}


