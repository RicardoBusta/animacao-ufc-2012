#ifndef CURVE_H
#define CURVE_H
#include <math/vec4.h>
#include <QtOpenGL>
class Curve {
public:
    virtual Vec4 Evaluate(double t) = 0;
    virtual Vec4 Velocity(double t) = 0;
    virtual Vec4 Aceleration(double t) = 0;
    virtual void draw(QList<Vec4> vertexs) = 0;
    virtual void drawCurve(QList<Vec4> Vertexs,bool show_polygon,bool show_curve) = 0;
    virtual void drawPolygon(QList<Vec4> Vertexs) = 0;
    virtual Vec4 a() = 0; //paramêtros para calcular o arclength
    virtual Vec4 b() = 0; //paramêtros para calcular o arclength
    virtual Vec4 c() = 0; //paramêtros para calcular o arclength

};


class BezierCubic : public Curve {
public:
    BezierCubic();
    BezierCubic(Vec4 a,Vec4 b, Vec4 c,Vec4 d);
    Vec4 Evaluate(double t);
    Vec4 Velocity(double t);
    Vec4 Aceleration(double t);
    void drawCurve(QList<Vec4> Vertexs,bool show_polygon,bool show_curve);
    void drawPolygon(QList<Vec4> Vertexs);
    void draw(QList<Vec4> vertexs);
    Vec4 a();
    Vec4 b();
    Vec4 c();


public:
    Vec4 p_a,p_b,p_c,p_d;
    double p_size,l_size;

};

class CatmullRomSpline : public Curve {
public:
    CatmullRomSpline();
    CatmullRomSpline(Vec4 a,Vec4 b, Vec4 c,Vec4 d);
    Vec4 Evaluate(double t);
    Vec4 Velocity(double t);
    Vec4 Aceleration(double t);
    void drawCurve(QList<Vec4> Vertexs,bool show_polygon,bool show_curve);
    void drawPolygon(QList<Vec4> Vertexs);
    void draw(QList<Vec4> vertexs);
    Vec4 a();
    Vec4 b();
    Vec4 c();


public:
    Vec4 p_a,p_b,p_c,p_d;
    double p_size,l_size;

};
#endif // CURVE_H

