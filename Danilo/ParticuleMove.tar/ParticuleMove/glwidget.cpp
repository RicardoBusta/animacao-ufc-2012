#include "glwidget.h"

GLWidget::GLWidget(QObject *parent) :
    QGLWidget(parent)
{
}
