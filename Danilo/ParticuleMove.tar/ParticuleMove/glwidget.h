#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QGLWidget>

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    explicit GLWidget(QObject *parent = 0);

signals:

public slots:

};

#endif // GLWIDGET_H
