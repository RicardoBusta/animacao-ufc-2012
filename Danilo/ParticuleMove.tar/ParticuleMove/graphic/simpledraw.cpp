#include "simpledraw.h"
#include <QtOpenGL>
SimpleDraw::SimpleDraw()
{
}

void SimpleDraw::drawAxis(double length,double size)
{
    glLineWidth(size);
    glColor4f(1.0,0.0,0.0,0.8);
    glBegin(GL_LINES);
       glVertex3d(length,0.0,0.0);
       glVertex3d(0.0,0.0,0.0);
    glEnd();
    glColor4f(0.0,1.0,0.0,0.8);
    glBegin(GL_LINES);
       glVertex3d(0.0,length,0.0);
       glVertex3d(0.0,0.0,0.0);
    glEnd();
    glColor4f(0.0,0.0,1.0,0.8);
    glBegin(GL_LINES);
       glVertex3d(0.0,0.0,length);
       glVertex3d(0.0,0.0,0.0);
    glEnd();
}
