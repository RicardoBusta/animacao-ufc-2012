#ifndef SIMPLEDRAW_H
#define SIMPLEDRAW_H

class SimpleDraw
{
public:
    SimpleDraw();
    static void drawAxis(double length,double size);
};

#endif // SIMPLEDRAW_H
