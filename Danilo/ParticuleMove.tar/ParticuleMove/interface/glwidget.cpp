#include "glwidget.h"

int z =0;
static int vision;
static int velocity_zoom = 1;
bool show_axis = true;
double easy_k1,easy_k2;
/************************ Variables Track-Ball**************************/
int winWidth,winHeight;
float xangle = 0.0,axis[3],trans[3];
bool p;
bool trackingMouse = false;
bool redrawContinue = false;
bool trackballMove = false;
float lastPos[3];
int curx,cury;
int startX,startY;
/************************ Funções do TrackBall *************************/

void GLWidget::trackball_ptov(int x, int y, int width, int height, float v[3])
{
    float d,a;
    //Projeta x,y em uma esfera contrada com width e height
    v[0] = (2.0*x - width) / width;
    v[1] = (height - 2.0*y) / height;
    d = (float) sqrt(v[0]*v[0]+v[1]*v[1]);
    v[2] = (float) cos((M_PI/2.0)*((d<1.0) ? d: 1.0));
    a = 1.0 / (float) sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
    v[0] *=a;
    v[1] *=a;
    v[2] *=a;
}

void GLWidget::startMotion(int x, int y){
    trackingMouse = true;
    redrawContinue = false;
    startX = x;
    startY = y;
    curx = x;
    cury = y;
    trackball_ptov(x,y,winWidth,winHeight,lastPos);
    trackballMove = true;
}

void GLWidget::stopMotion(int x,int y){
    trackingMouse = false;
    if(startX != x || startY != y){
        redrawContinue = true;
    }else{
        xangle = 0.0;
        redrawContinue = false;
        trackballMove = false;
    }
}

GLWidget::GLWidget(QWidget *parent) :  QGLWidget(parent)
{
     connect(&timer,SIGNAL(timeout()),this,SLOT(updateGL()));

     timer.start(10);
     KeyFrames.clear();
     lastPos[0] = 0.0;
     lastPos[1] = 0.0;
     lastPos[2] = 0.0;
     vision = 2;
     p_size = 1;
     l_size = 1;
     type_curve = 0;
     type_speed = 0;
     setMouseTracking(true);
     show_curve = true;
     show_polygon = false;
     show_control_points = true;
     time_specific = -1;
     time_current = 0;
     time_s = 1;
     time_m = 100;
     setSliderValue(100);
     play = false;
     stop = true;
     in_loop = false;
     easy_k1 = 0.3;
     easy_k2 = 0.7;
     follow_camera = false;
     type_camera = 0;
}
/*******************  Slots  ************************/
void GLWidget::setKey(double x, double y, double z){
    if((type_curve==0)&&(KeyFrames.size()==4)) return; //caso da curva ser cubica, somente 4 pontos de controle
    Vec4 key(x,y,z);
    if(KeyFrames.size()==0) KeyFrames.append(key);
    if(!(key == KeyFrames[KeyFrames.size()-1])) KeyFrames.append(key);
    return;
}

void GLWidget::removeKey(int pos){
    KeyFrames.removeAt(pos);
}

void GLWidget::setPointSize(double s)
{
    p_size = s;
}

void GLWidget::setTypeCurve(int c){
    type_curve = c;
}

void GLWidget::setTypeSpeed(int speed)
{
    type_speed = speed;
}

void GLWidget::setShowPolygon(bool b)
{
    show_polygon = b;
}

void GLWidget::setShowCurve(bool b)
{
    show_curve = b;
}

void GLWidget::setDefaultPosition()
{
    time_specific = -1;
}

void GLWidget::playAnimation()
{
    play = true;
    stop = false;
}

void GLWidget::stopAnimation()
{
    if(!play){
        time_current = 0;
        setSliderValue(0);
    }
    play = false;
    stop = true;
}
void GLWidget::setShowControlPoints(bool b)
{
    show_control_points = b;
}

void GLWidget::setLineSize(double s)
{
    l_size = s;
}

void GLWidget::setAnimationLoop(bool b)
{
    in_loop = b;
}

/****************** Signals *************************/
QList<Vec4> GLWidget::showKeyFrames(){
    return KeyFrames;
}

void GLWidget::initializeGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClearDepth(1.0);
    glDepthFunc(GL_LEQUAL);

    glEnable(GL_DEPTH_TEST);
    glCullFace(GL_FRONT_FACE);
    glEnable(GL_CULL_FACE);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_COLOR_MATERIAL);

}

void GLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //glLoadIdentity();
    if(show_axis) SimpleDraw::drawAxis(1.0,0.5);
    drawCurve();
    drawParticule();
    glColor3f(1,1,1);
    if (show_control_points) for (int i=0;i<KeyFrames.size();i++) KeyFrames[i].drawVec4(p_size);
    if(trackingMouse) glRotatef(xangle,axis[0],axis[1],axis[2]);


}

void GLWidget::resizeGL(int w, int h)
{
    winHeight = h;
    winWidth  = w;
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45,(float)w/h,0.001,120000.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(vision,vision,vision, 0,0,0, 0,1,0);

}

/********************* Funções do Mouse *******************************/
void GLWidget::mousePressEvent(QMouseEvent *event)
{
    trackingMouse = true;
    int x,y;
    x = event->pos().x();
    y = event->pos().y();
    if(event->buttons() && Qt::LeftButton){
        if(hasMouseTracking()){
            y = winHeight - y;
            startMotion(x,y);
        }else
            {
                stopMotion(x,y);
            }
     }
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
    int x,y;
    float curPos[3], dx,dy,dz;
    x = event->pos().x();
    y = event->pos().y();
    trackball_ptov(x,y,winWidth,winHeight,curPos);
    if(trackingMouse && event->buttons()){
        dx = curPos[0] - lastPos[0];
        dy = curPos[1] - lastPos[1];
        dz = curPos[2] - lastPos[2];

        if(dx || dy || dz){
            xangle = 90.0 * sqrt(dx*dx+dy*dy+dz*dz);
            axis[0] = lastPos[1]*curPos[2] - lastPos[2]*curPos[1];
            axis[1] = lastPos[2]*curPos[0] - lastPos[0]*curPos[2];
            axis[2] = lastPos[0]*curPos[1] - lastPos[1]*curPos[0];
            lastPos[0] = curPos[0];
            lastPos[1] = curPos[1];
            lastPos[2] = curPos[2];
        }
    }else{
        stopMotion(x,y);
    }
}

void GLWidget::wheelEvent(QWheelEvent *event){
   int numDegrees = event->delta() / 8;
   int numSteps = numDegrees / 15;
   if (numSteps>0){
      vision += 1+(0.5*velocity_zoom);
   }
   else{
      if (!(vision<0.5)){
      vision -= 1+(0.5*velocity_zoom);
      }
   }
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   gluLookAt(vision,vision,vision, 0,0,0, 0,1,0);

}

void GLWidget::drawCurve()
{
    if(type_curve==0 && KeyFrames.size()==4){
        beziercubic = new BezierCubic();
        beziercubic->l_size = l_size;
        beziercubic->drawCurve(KeyFrames,show_polygon,show_curve);
    }
    if(type_curve==1 && KeyFrames.size()>1){
        catmullromspline = new CatmullRomSpline();
        catmullromspline->l_size = l_size;
        catmullromspline->drawCurve(KeyFrames,show_polygon,show_curve);
    }
}

void GLWidget::setTotalTime(int t)
{
    time_m = t*100;
    time_s = t;
}

void GLWidget::setParticulePosition(int p)
{
    time_specific = p;
}

void GLWidget::drawParticule()
{

    //printf("tempo: %d",tempo);
    glColor3f(0.0,1.0,1.0);

    //double stimative = (sin((tempo/500.0)*M_PI - M_PI/2.0)+1)/2.0; caso easy-in easy-out
    //double v = 1.5;
    //double s = (tempo/500.0)*(tam*20) + (1*(tempo/500.0));
    //if (s>tam*20) tempo = s = 0;
    if(type_curve==0 && KeyFrames.size()==4){
        arc.adaptive_integration(beziercubic,0.0,1.0,0.0000001);
        if(time_specific != -1){
            time_current = time_specific;
            double stimative = 0.0;
            if (type_speed==0) {
                stimative = time_current/((double)time_m);
            }else{
                stimative = SpeedControl::easyIn_easyOut(time_current/((double)time_m),easy_k1,easy_k2);
            }
            Vec4 tp = arc.getVec4S(beziercubic,arc.length*stimative);
            tp.drawVec4();
            if (follow_camera){
                Vec4 w = arc.getVec4V(beziercubic,arc.length*stimative);
                Vec4 u = arc.getVec4A(beziercubic,arc.length*stimative);
                u = Vec4::crossProduct(w,u);
                Vec4 v = Vec4::crossProduct(w,u);
                u = u.unitary();
                w = w.unitary();
                v = v.unitary();
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                switch (type_camera){
                case 0:
                {
                    gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 1:
                {
                    gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 2:
                {
                    gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                }



            }
        }else{
            if (stop){
                double stimative = 0.0;
                if (type_speed==0) {
                    stimative = time_current/((double)time_m);
                }else{
                    stimative = SpeedControl::easyIn_easyOut(time_current/((double)time_m),easy_k1,easy_k2);
                }
                Vec4 tp = arc.getVec4S(beziercubic,arc.length*stimative);
                tp.drawVec4();
                if (follow_camera){
                    Vec4 w = arc.getVec4V(beziercubic,arc.length*stimative);
                    Vec4 u = arc.getVec4A(beziercubic,arc.length*stimative);
                    u = Vec4::crossProduct(w,u);
                    Vec4 v = Vec4::crossProduct(w,u);
                    u = u.unitary();
                    w = w.unitary();
                    v = v.unitary();
                    glMatrixMode(GL_MODELVIEW);
                    glLoadIdentity();
                    switch (type_camera){
                    case 0:
                    {
                        gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 1:
                    {
                        gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 2:
                    {
                        gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    }



                }
                return;
            }
            if(time_current>time_m)
            {
                time_current = 0;
                if (! in_loop){
                   play = false;
                   stop = true;
                }
            }
            setSliderValue(time_current);

            double stimative = 0.0;
            stimative = time_current/((double)time_m);
            if (type_speed==0) {
                stimative = time_current/((double)time_m);
            }else{
                stimative = SpeedControl::easyIn_easyOut(stimative,easy_k1,easy_k2);
            }
            Vec4 tp = arc.getVec4S(beziercubic,arc.length*stimative);
            if (follow_camera){
                Vec4 w = arc.getVec4V(beziercubic,arc.length*stimative);
                Vec4 u = arc.getVec4A(beziercubic,arc.length*stimative);
                u = Vec4::crossProduct(w,u);
                Vec4 v = Vec4::crossProduct(w,u);
                u = u.unitary();
                w = w.unitary();
                v = v.unitary();
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                switch (type_camera){
                    case 0:
                    {
                        gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 1:
                    {
                        gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 2:
                    {
                        gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    //default : gluLookAt(2, 2, 2,tp.x1,tp.x2,tp.x3, 0,1,0);
                }



            }




            tp.drawVec4();
            time_current += 1;


        }
    }
    double total_length = 0.0;

    arcs.clear();
    if(type_curve==1 && KeyFrames.size()>1){

        for(int i = 0;i<KeyFrames.size()-1;i++){
            Vec4 p_a,p_b,p_c,p_d;
            p_a = KeyFrames[std::max(0,i-1)];
            p_b = KeyFrames[i];
            p_c = KeyFrames[std::min(i+1,KeyFrames.size()-1)];
            p_d = KeyFrames[std::min(i+2,KeyFrames.size()-1)];
            CatmullRomSpline *slice = new CatmullRomSpline();
            slice->p_a = p_a;
            slice->p_b = p_b;
            slice->p_c = p_c;
            slice->p_d = p_d;
            //catmulls->append(slice);
            ArcLength_ arc_slice;
            arc_slice.adaptive_integration(slice,0,1,0.000001);
            arcs.append(arc_slice);
        }
        arc_acumulate.clear();

        for(int i = 0;i<arcs.length();i++){
            total_length += arcs[i].length;
            arc_acumulate.append(total_length);
        }
        if(time_specific != -1){
            time_current = time_specific;
            int curve_i;
            double stimative =0.0;
            if (type_speed==0) {
                stimative = time_current/((double)time_m);
            }else{
                stimative = SpeedControl::easyIn_easyOut(time_current/((double)time_m),easy_k1,easy_k2);
            }

            double space_p = stimative*total_length;
            for(int i = 0;i<arcs.size();i++)
                if(arc_acumulate[i]>=space_p){
                    curve_i = i;
                    break;
                }
            Vec4 p_a,p_b,p_c,p_d;
            p_a = KeyFrames[std::max(0,curve_i-1)];
            p_b = KeyFrames[curve_i];
            p_c = KeyFrames[std::min(curve_i+1,KeyFrames.size()-1)];
            p_d = KeyFrames[std::min(curve_i+2,KeyFrames.size()-1)];
            CatmullRomSpline *slice = new CatmullRomSpline(p_a,p_b,p_c,p_d);

            Vec4 tp = arcs[curve_i].getVec4S(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
            tp.drawVec4();
            if (follow_camera){
                Vec4 w = arcs[curve_i].getVec4V(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                Vec4 u = arcs[curve_i].getVec4A(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                u = Vec4::crossProduct(w,u);
                Vec4 v = Vec4::crossProduct(w,u);
                u = u.unitary();
                w = w.unitary();
                v = v.unitary();
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                switch (type_camera){
                case 0:
                {
                    gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 1:
                {
                    gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 2:
                {
                    gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                }



            }
        }
        else{
            if (stop){
                int curve_i;
                double stimative =0.0;
                if (type_speed==0) {
                    stimative = time_current/((double)time_m);
                }else{
                    stimative = SpeedControl::easyIn_easyOut(time_current/((double)time_m),easy_k1,easy_k2);
                }
                double space_p = stimative*total_length;
                for(int i = 0;i<arcs.size();i++)
                    if(arc_acumulate[i]>=space_p){
                        curve_i = i;
                        break;
                    }
                Vec4 p_a,p_b,p_c,p_d;
                p_a = KeyFrames[std::max(0,curve_i-1)];
                p_b = KeyFrames[curve_i];
                p_c = KeyFrames[std::min(curve_i+1,KeyFrames.size()-1)];
                p_d = KeyFrames[std::min(curve_i+2,KeyFrames.size()-1)];
                CatmullRomSpline *slice = new CatmullRomSpline(p_a,p_b,p_c,p_d);

                Vec4 tp = arcs[curve_i].getVec4S(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                tp.drawVec4();
                if (follow_camera){
                    Vec4 w = arcs[curve_i].getVec4V(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                    Vec4 u = arcs[curve_i].getVec4A(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                    u = Vec4::crossProduct(w,u);
                    Vec4 v = Vec4::crossProduct(w,u);
                    u = u.unitary();
                    w = w.unitary();
                    v = v.unitary();
                    glMatrixMode(GL_MODELVIEW);
                    glLoadIdentity();
                    switch (type_camera){
                    case 0:
                    {
                        gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 1:
                    {
                        gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    case 2:
                    {
                        gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                        break;
                    }
                    }



                }
                return;
            }
            if(time_current>time_m)
            {
                time_current = 0;
                if (! in_loop){
                   play = false;
                   stop = true;
                }
            }
            setSliderValue(time_current);
            int curve_i;
            double stimative =0.0;
            if (type_speed==0) {
                stimative = time_current/((double)time_m);

            }else{
                stimative = SpeedControl::easyIn_easyOut(time_current/((double)time_m),easy_k1,easy_k2);
            }
            double space_p = stimative*total_length;
            for(int i = 0;i<arcs.size();i++)
                if(arc_acumulate[i]>=space_p){
                    curve_i = i;
                    break;
                }
            Vec4 p_a,p_b,p_c,p_d;
            p_a = KeyFrames[std::max(0,curve_i-1)];
            p_b = KeyFrames[curve_i];
            p_c = KeyFrames[std::min(curve_i+1,KeyFrames.size()-1)];
            p_d = KeyFrames[std::min(curve_i+2,KeyFrames.size()-1)];
            CatmullRomSpline *slice = new CatmullRomSpline(p_a,p_b,p_c,p_d);

            Vec4 tp = arcs[curve_i].getVec4S(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
            tp.drawVec4();
            if (follow_camera){
                Vec4 w = arcs[curve_i].getVec4V(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                Vec4 u = arcs[curve_i].getVec4A(slice,arcs[curve_i].length-(arc_acumulate[curve_i]-space_p));
                u = Vec4::crossProduct(w,u);
                Vec4 v = Vec4::crossProduct(w,u);
                u = u.unitary();
                w = w.unitary();
                v = v.unitary();
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                switch (type_camera){
                case 0:
                {
                    gluLookAt(u.x1,u.x2,u.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 1:
                {
                    gluLookAt(v.x1,v.x2,v.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                case 2:
                {
                    gluLookAt(w.x1,w.x2,w.x3, tp.x1,tp.x2,tp.x3, 0,1,0);
                    break;
                }
                }



            }
            time_current += 1;
        }
}

}



void GLWidget::keyPressEvent(QKeyEvent *e)
{
    printf("\nKey");
    if (e->key() == Qt::Key_Escape) {
        printf("\nDeu certo - - Key");
    }
}

void GLWidget::showAxis()
{
    show_axis = (! show_axis);
}

void GLWidget::showPlayStop()
{
    play = !play;
    stop = !stop;
}



void GLWidget::setFollowCamera(bool b)
{
    if (! b){
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        gluLookAt(vision,vision,vision, 0,0,0, 0,1,0);
    }
    follow_camera = b;
}

void GLWidget::setTypeCamera(int t)
{
    type_camera = t;
    setFollowCameraR(true);
    follow_camera = true;
}

void GLWidget::setCameraType1()
{
    type_camera = 0;
    setTypeCameraSelection(0);
    setFollowCameraR(true);
    follow_camera = true;
}

void GLWidget::setCameraType2()
{
    type_camera = 1;
    setTypeCameraSelection(1);
    setFollowCameraR(true);
    follow_camera = true;
}

void GLWidget::setCameraType3()
{
    type_camera = 2;
    setTypeCameraSelection(2);
    setFollowCameraR(true);
    follow_camera = true;
}

void GLWidget::downExemple()
{
    KeyFrames.clear();
    KeyFrames.append(Vec4(0.0,0.0,0.0));
    KeyFrames.append(Vec4(1.0,2.0,1.0));
    KeyFrames.append(Vec4(-0.5,0.5,-0.5));
    KeyFrames.append(Vec4(1.0,1.0,0.5));
    showKeyFrames();
}




