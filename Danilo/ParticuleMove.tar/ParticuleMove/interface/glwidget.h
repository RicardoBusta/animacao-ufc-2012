#ifndef GLWIDGET_H
#define GLWIDGET_H
#include <QTimer>
#include <QList>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QKeyEvent>
#include <math/vec4.h>
#include <QGLWidget>
#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <stdio.h>
#include <graphic/simpledraw.h>
#include <curve/curve.h>
#include <curve/arclength_.h>
#include <vector>
#include <control/speedcontrol.h>

class GLWidget : public QGLWidget
{
    Q_OBJECT
public:
    QList<Vec4> KeyFrames;
    QTimer timer;
    double p_size,l_size;
    int type_curve,type_speed;
    int time_s,time_m,time_specific,time_current,type_camera;
    bool show_polygon,show_curve,show_control_points,play,stop,in_loop,follow_camera;
    BezierCubic *beziercubic;
    CatmullRomSpline *catmullromspline;
    QList<CatmullRomSpline> *catmulls;
    QList<ArcLength_> arcs;
    ArcLength_ arc;
    QVector<double> arc_acumulate;


public slots:
    void setKey(double x,double y, double z);
    void removeKey(int pos);
    QList<Vec4> showKeyFrames();
    void setPointSize(double s);
    void setLineSize(double s);
    void setTypeCurve(int curve);
    void setTypeSpeed(int speed);
    void setShowPolygon(bool b);
    void setShowCurve(bool b);
    void setTotalTime(int t);
    void setParticulePosition(int p);
    void setDefaultPosition();
    void setShowControlPoints(bool b);
    void playAnimation();
    void stopAnimation();
    void setAnimationLoop(bool b);
    void showAxis();
    void showPlayStop();
    void setFollowCamera(bool b);
    void setTypeCamera(int t);
    void setCameraType1();
    void setCameraType2();
    void setCameraType3();
    void downExemple();

signals:
    void setSliderValue(int i);
    void setFollowCameraR(bool b);
    void setTypeCameraSelection(int i);
public:
    explicit GLWidget(QWidget *parent = 0);
    void initializeGL();
    void paintGL();
    void resizeGL(int w, int h);
    //funções de desenho
    void drawCurve();
    void drawParticule();
    //funções do mouse e teclado
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);
    void keyPressEvent(QKeyEvent *event);
    //funções de rotação
    void trackball_ptov(int x, int y, int width, int height, float v[3]);
    void startMotion(int x, int y);
    void stopMotion(int x, int y);

};

#endif // GLWIDGET_H
