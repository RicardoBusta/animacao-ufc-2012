#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QString>
#include <stdio.h>
int selectRow = -1;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    updateListKeys(ui->widget->showKeyFrames());
}


void MainWindow::setMaxSlider(int i){
    ui->horizontalSlider->setMaximum(i*100);
    ui->horizontalSlider->setValue(0);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_ButtonAddKey_clicked()
{
    ui->widget->setKey(ui->dPosX->value(),ui->dPosY->value(),ui->dPosZ->value());
    updateListKeys(ui->widget->showKeyFrames());
}

void MainWindow::on_ButtonDeleteKey_clicked()
{
    if(selectRow >= 0){
       ui->widget->removeKey(selectRow);
       updateListKeys(ui->widget->showKeyFrames());
    }
}



void MainWindow::on_listKeyFrame_currentRowChanged(int currentRow)
{
    selectRow = currentRow;
}


void MainWindow::updateListKeys(QList<Vec4> keys)
{
    ui->listKeyFrame->clear();
    ui->numKeys->setNum(keys.size());
    for (int i=0;i<keys.size();i++){
        ui->listKeyFrame->addItem(keys[i].stringVec4());
    }
}

