#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QList>
#include <math/vec4.h>
#include <QMainWindow>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void updateListKeys(QList<Vec4> keys);

private slots:
    void setMaxSlider(int);
    void on_ButtonAddKey_clicked();

    void on_ButtonDeleteKey_clicked();

    void on_listKeyFrame_currentRowChanged(int currentRow);





private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
