#ifndef MATRIX4F_H
#define MATRIX4F_H

class Matrix4f
{
public:
    Matrix4f();
};

#endif // MATRIX4F_H
