#include "quaternion.h"

//functions publics
Quaternion::Quaternion()
{
}

Quaternion::Quaternion(double r, double x, double y, double z)
{
    this->s = r;
    this->x = x;
    this->y = y;
    this->z = z;
}

Quaternion::Quaternion(double r, Vec4 v)
{
    this->s = r;
    this->x = v.x1;
    this->y = v.x2;
    this->z = v.x3;
}

//sets

void Quaternion::setScalar(double x)
{
    this->s = x;
}

void Quaternion::setPosX(double x)
{
    this->x = x;
}

void Quaternion::setPosY(double x)
{
    this->y = x;
}

void Quaternion::setPosZ(double x)
{
    this->z = x;
}

void Quaternion::setQuaternion(double r, double x, double y, double z)
{
    this->s = r;
    this->x = x;
    this->y = y;
    this->z = z;
}

void Quaternion::setQuaternion(double r, Vec4 v)
{
    this->s = r;
    this->x = v.x1;
    this->y = v.x2;
    this->z = v.x3;
}

//end sets
//gets

double Quaternion::getScalar()
{
    return this->s;
}

double Quaternion::getPosX()
{
    return this->x;
}

double Quaternion::getPosY()
{
    return this->y;
}

double Quaternion::getPosZ()
{
    return this->z;
}

Vec4 Quaternion::getVector()
{
    Vec4 v;
    v.setVec4(this->getPosX(),this->getPosY(),this->getPosZ());
    return v;
}

//end gets
//functions

Quaternion Quaternion::conjugate()
{
    Quaternion res(this->getScalar(),this->getVector()*(-1));
    return res;
}

double Quaternion::normal()
{
    double res;
    res = sqrt(this->getScalar()*this->getScalar()+this->getVector().module()*this->getVector().module());
    return res;
}

void Quaternion::toAxisAngle(Vec4 *axis, double *angle)
{
    double scale = this->getVector().module();
    axis->x1 = getPosX()/scale;
    axis->x2 = getPosY()/scale;
    axis->x3 = getPosZ()/scale;
    *angle = acos(getScalar()) * 2.0;
}

//operadores

Quaternion Quaternion::operator +(Quaternion q)
{
    Quaternion res;
    res.setScalar(this->getScalar()+q.getScalar());
    res.setPosX(this->getPosX()+q.getPosX());
    res.setPosY(this->getPosY()+q.getPosY());
    res.setPosZ(this->getPosZ()+q.getPosZ());
    return res;
}

Quaternion Quaternion::operator -(Quaternion q)
{
    Quaternion res;
    res.setScalar(this->getScalar()-q.getScalar());
    res.setPosX(this->getPosX()-q.getPosX());
    res.setPosY(this->getPosY()-q.getPosY());
    res.setPosZ(this->getPosZ()-q.getPosZ());
    return res;
}

Quaternion Quaternion::operator *(double k)
{
    Quaternion res;
    res.setScalar(this->getScalar()*k);
    res.setPosX(this->getPosX()*k);
    res.setPosY(this->getPosY()*k);
    res.setPosZ(this->getPosZ()*k);
    return res;
}

Quaternion Quaternion::operator *(Quaternion q)
{
    //q1q2 = (s1 , v1)(s2 , v2) = (s1*s2 − v1⋅v 2 , s1v2 + s2v1 + v1 × v2 )
    Quaternion res;
    Vec4 v;
    res.setScalar(this->getScalar()*q.getScalar() - this->getVector()*this->getVector());
    v.setVec4(q.getVector()*this->getScalar()+this->getVector()*q.getScalar()+Vec4::crossProduct(this->getVector(),q.getVector()));
    res.setPosX(v.x1);
    res.setPosY(v.x2);
    res.setPosZ(v.x3);
    return res;
}

//end operadores





