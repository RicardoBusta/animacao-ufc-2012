#ifndef QUATERNION_H
#define QUATERNION_H
#include "vec4.h"

class Quaternion
{
private:
    double s,x,y,z;
public:
    Quaternion();
    Quaternion(double r,double x, double y, double z);
    Quaternion(double r, Vec4 v);
    //sets
    void setQuaternion(double r,double x, double y, double z);
    void setQuaternion(double r, Vec4 v);
    void setScalar(double s);
    void setPosX(double x);
    void setPosY(double y);
    void setPosZ(double z);
    //gets
    double getScalar(); //escalar
    double getPosX(); //coordenada x
    double getPosY(); //coordenada y
    double getPosZ(); //coordenada z
    Vec4 getVector();
    //fuctions
    Quaternion conjugate(); //conjugado do quaternion
    double normal(); //módulo
    void toAxisAngle(Vec4 *axis, double *angle); //converter um quaternion para eixo e angulo
    //operadores
    Quaternion operator +(Quaternion q);
    Quaternion operator -(Quaternion q);
    Quaternion operator *(double k);
    Quaternion operator *(Quaternion q);



};

#endif // QUATERNION_H
